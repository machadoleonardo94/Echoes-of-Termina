"""
LED canvas — DXF-driven zone rendering.

Loads the 12 zones from assets/areas_clean.dxf and renders them as
individually colourable regions.  Falls back to majoras.png placeholder
if the DXF is unavailable.

Zone colour rules
─────────────────
• If the script engine has set a colour for zone N  → fill with that RGB,
  plus a soft glow outline.
• Otherwise                                         → dim translucent fill
  with a muted blue-grey stroke.
"""
from __future__ import annotations

import os
from typing import Optional

from PySide6.QtCore    import Qt, QPointF, QRectF, Signal
from PySide6.QtGui     import (
    QBrush, QColor, QFont, QPainter, QPen, QPixmap, QTransform,
)
from PySide6.QtWidgets import QMenu, QWidget

_ASSETS = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'assets')
_DXF    = os.path.join(_ASSETS, 'areas_clean.dxf')

_BG          = QColor("#1e1e1e")
_OFF_FILL    = QColor(40,  50,  60,  70)    # dim unlit fill
_OFF_STROKE  = QColor(60,  90, 120, 140)    # muted blue outline
_LABEL_DIM   = QColor(90, 110, 130)         # unlit label
_LABEL_LIT   = QColor(230, 230, 230)        # lit label


class LEDCanvas(QWidget):
    """Renders 12 DXF-sourced LED zones with live colours from the script engine."""

    zone_right_clicked = Signal(int)   # zone_id — emitted on right-click over a zone

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._led_states: dict = {}       # {1-based zone id: (r, g, b)}
        self._zones:      list = []       # list[DxfZone]
        self._pixmap: Optional[QPixmap] = _load_mask()
        self._last_transform: QTransform = QTransform()
        self.setMinimumSize(320, 240)
        self._try_load_dxf()

    # ── Public API ────────────────────────────────────────────────────────────

    def update_leds(self, states: dict) -> None:
        """Receive evaluated LED colour map {zone_id: (r,g,b)} and repaint."""
        self._led_states = states
        self.update()

    # ── Qt overrides ─────────────────────────────────────────────────────────

    def paintEvent(self, _event) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        w, h = self.width(), self.height()
        painter.fillRect(0, 0, w, h, _BG)

        if self._zones:
            self._draw_zones(painter, w, h)
        elif self._pixmap:
            _draw_pixmap(painter, self._pixmap, w, h)
        else:
            _draw_placeholder(painter, w, h)

        painter.end()

    # ── Private ───────────────────────────────────────────────────────────────

    def _try_load_dxf(self) -> None:
        if not os.path.isfile(_DXF):
            return
        try:
            from core.dxf_loader import load_zones
            self._zones = load_zones(_DXF)
        except Exception as exc:
            print(f'[LEDCanvas] DXF load failed: {exc}')

    def contextMenuEvent(self, event) -> None:
        """Right-click on a zone: emit zone_right_clicked with its ID."""
        if not self._zones:
            event.ignore()
            return
        inv, ok = self._last_transform.inverted()
        if not ok:
            event.ignore()
            return
        dxf_pt = inv.map(QPointF(event.pos()))
        for zone in self._zones:
            if zone.path.contains(dxf_pt):
                self.zone_right_clicked.emit(zone.zone_id)
                event.accept()
                return
        event.ignore()

    def _build_transform(self, w: int, h: int) -> QTransform:
        """
        Compute a QTransform from DXF coordinate space to screen space
        that centres all zones and fills ~88% of the canvas.
        """
        all_x = [z.xmin for z in self._zones] + [z.xmax for z in self._zones]
        all_y = [z.ymin for z in self._zones] + [z.ymax for z in self._zones]
        dxf_cx = (min(all_x) + max(all_x)) / 2
        dxf_cy = (min(all_y) + max(all_y)) / 2
        dxf_w  = max(all_x) - min(all_x) or 1
        dxf_h  = max(all_y) - min(all_y) or 1
        scale  = min(w / dxf_w, h / dxf_h) * 0.88

        t = QTransform()
        t.translate(w / 2, h / 2)       # move origin to canvas centre
        t.scale(scale, scale)           # scale only — DXF uses Y-down (screen convention)
        t.translate(-dxf_cx, -dxf_cy)  # centre DXF world
        self._last_transform = t
        return t

    def _draw_zones(self, painter: QPainter, w: int, h: int) -> None:
        t    = self._build_transform(w, h)
        font = QFont("Consolas", 8)
        font.setBold(True)
        painter.setFont(font)

        # Cosmetic pen: always 1 px wide on screen regardless of zoom
        off_pen = QPen(_OFF_STROKE, 1.2)
        off_pen.setCosmetic(True)

        for zone in self._zones:
            rgb = self._led_states.get(zone.zone_id)

            painter.setTransform(t)

            if rgb:
                r, g, b = rgb
                lit_color  = QColor(r, g, b, 210)
                glow_color = QColor(r, g, b,  50)
                glow_pen   = QPen(QColor(r, g, b, 160), 3.0)
                glow_pen.setCosmetic(True)

                # Glow outline
                painter.setPen(glow_pen)
                painter.setBrush(QBrush(glow_color))
                painter.drawPath(zone.path)

                # Solid fill
                lit_pen = QPen(QColor(r, g, b).lighter(180), 1.2)
                lit_pen.setCosmetic(True)
                painter.setPen(lit_pen)
                painter.setBrush(QBrush(lit_color))
                painter.drawPath(zone.path)
            else:
                painter.setPen(off_pen)
                painter.setBrush(QBrush(_OFF_FILL))
                painter.drawPath(zone.path)

            # Zone number label — drawn in screen space at the centroid
            painter.setTransform(QTransform())
            sp     = t.map(QPointF(zone.cx, zone.cy))
            lcolor = _LABEL_LIT if rgb else _LABEL_DIM
            painter.setPen(QPen(lcolor))
            painter.drawText(
                QRectF(sp.x() - 14, sp.y() - 8, 28, 16),
                Qt.AlignmentFlag.AlignCenter,
                str(zone.zone_id),
            )


# ── Module-level helpers ──────────────────────────────────────────────────────

def _load_mask() -> Optional[QPixmap]:
    path = os.path.join(_ASSETS, "majoras.png")
    if os.path.isfile(path):
        px = QPixmap(path)
        return px if not px.isNull() else None
    return None


def _draw_pixmap(painter: QPainter, px: QPixmap, w: int, h: int) -> None:
    scaled = px.scaled(w, h,
                       Qt.AspectRatioMode.KeepAspectRatio,
                       Qt.TransformationMode.SmoothTransformation)
    painter.drawPixmap((w - scaled.width()) // 2,
                       (h - scaled.height()) // 2, scaled)


def _draw_placeholder(painter: QPainter, w: int, h: int) -> None:
    painter.setPen(QColor("#3a3a3a"))
    painter.drawRect(2, 2, w - 4, h - 4)
    painter.setPen(QColor("#555555"))
    painter.drawText(0, 0, w, h, Qt.AlignmentFlag.AlignCenter,
                     "LED canvas\n\nPlace assets/areas_clean.dxf")

